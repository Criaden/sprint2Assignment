<?php

define("MUSER","menzia_s_user");
define("MPASS","puc26qox");
define("MSERVER","cnmtsrv2.uwsp.edu");
define("MDB","menzia_s");

if (basename($_SERVER['PHP_SELF']) == "const.php") {
  die(header("HTTP/1.0 404 Not Found"));
}

?>
