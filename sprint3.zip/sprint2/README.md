# phpclasses_template
See testTemplate.php for usage instructions.
Also note comments within Template.php too.
