<?php

define("MUSER","menzia_s_admin");
define("MPASS","zyj72xor");
define("MSERVER","cnmtsrv1.uwsp.edu");
define("MDB","menzia_s");

if (basename($_SERVER['PHP_SELF']) == "const.php") {
  die(header("HTTP/1.0 404 Not Found"));
}

?>
